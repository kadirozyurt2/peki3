import React from "react";

const Item = () => {
  return (
    <>
      <div className="col-lg-4 item">
        <img src="/images/Increase.svg" alt="" />
        <h6>Discover our blog</h6>
        <p>Increase product sales, customer fast engagement, generate.</p>
      </div>
    </>
  );
};

export default Item;
