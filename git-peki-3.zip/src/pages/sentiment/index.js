import React from 'react'
import Sentiment from '@/components/sentiment/Sentiment'

const index = () => {
  return (
    <>
        <Sentiment />
    </>
  )
}

export default index